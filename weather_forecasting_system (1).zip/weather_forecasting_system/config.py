"""
Application configuration.
All values can be overridden by environment variables (see .env).
"""

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent


class Config:
    # ----------------------------------------------------------------
    # Core
    # ----------------------------------------------------------------
    SECRET_KEY = os.environ.get("SECRET_KEY", "dev-key-change-in-production")
    DEBUG = os.environ.get("FLASK_DEBUG", "False").lower() == "true"
    HOST = os.environ.get("FLASK_HOST", "127.0.0.1")
    PORT = int(os.environ.get("FLASK_PORT", 5000))
    LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO")

    # ----------------------------------------------------------------
    # Paths
    # ----------------------------------------------------------------
    DATA_DIR = BASE_DIR / "data"
    RAW_DATA = DATA_DIR / "raw" / "historical_weather.csv"
    PROCESSED_DATA = DATA_DIR / "processed" / "cleaned_weather.csv"
    MODEL_DIR = BASE_DIR / "models"
    TEMP_MODEL = MODEL_DIR / "temperature_model.pkl"
    RAIN_MODEL = MODEL_DIR / "rainfall_model.pkl"

    # ----------------------------------------------------------------
    # External weather API (OpenWeatherMap — free tier)
    # ----------------------------------------------------------------
    WEATHER_API_KEY = os.environ.get("WEATHER_API_KEY", "")
    WEATHER_API_BASE = "https://api.openweathermap.org/data/2.5"

    # ----------------------------------------------------------------
    # Database
    # ----------------------------------------------------------------
    DATABASE_PATH = BASE_DIR / "database" / "weather.db"

    # ----------------------------------------------------------------
    # Forecast behaviour
    # ----------------------------------------------------------------
    DEFAULT_CITY = os.environ.get("DEFAULT_CITY", "London")
    KNOWN_CITIES = [
        "London", "Paris", "New York", "Tokyo", "Sydney",
        "Mumbai", "Cairo", "Moscow", "Berlin", "Toronto",
        "Singapore", "Dubai", "Rio de Janeiro", "Nairobi", "Beijing",
    ]
    MAX_FORECAST_DAYS = 14

    # ----------------------------------------------------------------
    # Model settings
    # ----------------------------------------------------------------
    TRAIN_TEST_SPLIT = 0.2
    RANDOM_STATE = 42


class DevelopmentConfig(Config):
    DEBUG = True


class ProductionConfig(Config):
    DEBUG = False
    LOG_LEVEL = "WARNING"


class TestingConfig(Config):
    TESTING = True
    DEBUG = True
    DATABASE_PATH = BASE_DIR / "database" / "test_weather.db"


config_by_name = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "testing": TestingConfig,
    "default": Config,
}
