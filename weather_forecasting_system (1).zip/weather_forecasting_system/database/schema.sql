-- Weather Forecasting System — database schema
-- SQLite dialect

-- Daily forecast records (audit trail of every forecast served)
CREATE TABLE IF NOT EXISTS forecasts (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    city            TEXT        NOT NULL,
    forecast_date   TEXT        NOT NULL,          -- YYYY-MM-DD
    temperature     REAL,
    rain_probability REAL,
    created_date    TEXT        NOT NULL,          -- when the forecast was made
    UNIQUE (city, forecast_date, created_date)
);

CREATE INDEX IF NOT EXISTS idx_forecasts_city_date
    ON forecasts (city, forecast_date);

CREATE INDEX IF NOT EXISTS idx_forecasts_created
    ON forecasts (created_date);

-- Observed historical weather (mirrors cleaned_weather.csv)
CREATE TABLE IF NOT EXISTS observations (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    city             TEXT NOT NULL,
    date             TEXT NOT NULL,               -- YYYY-MM-DD
    temperature_min  REAL,
    temperature_max  REAL,
    temperature_mean REAL,
    rainfall_mm      REAL DEFAULT 0,
    humidity_pct     INTEGER,
    wind_kph         REAL,
    pressure_hpa     REAL,
    UNIQUE (city, date)
);

CREATE INDEX IF NOT EXISTS idx_observations_city_date
    ON observations (city, date);
