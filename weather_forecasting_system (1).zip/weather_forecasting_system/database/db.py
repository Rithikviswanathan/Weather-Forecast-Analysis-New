"""
db.py
=====
SQLite connection helpers and convenience functions.

All forecast writes pass through record_forecast() so the schema stays
consistent. get_db() returns a connection with Row access and foreign
keys enabled.
"""

import sqlite3
from datetime import datetime

from config import Config

SCHEMA_PATH = Config.DATABASE_PATH.parent / "schema.sql"


def get_db() -> sqlite3.Connection:
    conn = sqlite3.connect(Config.DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """Create tables if they don't already exist."""
    if not SCHEMA_PATH.exists():
        return
    with open(SCHEMA_PATH) as f:
        script = f.read()
    conn = get_db()
    conn.executescript(script)
    conn.commit()
    conn.close()


def record_forecast(city: str, forecast_date: str,
                    temperature: float | None = None,
                    rain_probability: float | None = None) -> int:
    """Insert a forecast record; returns the new row id."""
    conn = get_db()
    cur = conn.execute(
        """INSERT INTO forecasts
           (city, forecast_date, temperature, rain_probability, created_date)
           VALUES (?, ?, ?, ?, ?)""",
        (city, forecast_date, temperature, rain_probability,
         datetime.utcnow().strftime("%Y-%m-%d")),
    )
    conn.commit()
    row_id = cur.lastrowid
    conn.close()
    return row_id


def get_recent_forecasts(city: str, limit: int = 30) -> list:
    conn = get_db()
    rows = conn.execute(
        """SELECT * FROM forecasts WHERE city = ?
           ORDER BY forecast_date DESC LIMIT ?""",
        (city, limit),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_forecast_stats() -> dict:
    """Aggregate stats used on the about/performance pages."""
    conn = get_db()
    row = conn.execute(
        """SELECT COUNT(*) AS total,
                  COUNT(DISTINCT city) AS cities,
                  MIN(forecast_date) AS earliest,
                  MAX(forecast_date) AS latest
           FROM forecasts"""
    ).fetchone()
    conn.close()
    return dict(row)
