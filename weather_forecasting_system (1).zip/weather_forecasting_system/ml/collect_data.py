"""
collect_data.py
===============
Collects historical weather data and writes it to data/raw/historical_weather.csv.

Two modes:
  1. Live mode   — downloads data from the OpenWeatherMap "One Call" history
                   endpoint (requires WEATHER_API_KEY in .env).
  2. Simulated mode — when no API key is available, generates a realistic
                      synthetic dataset with seasonal cycles, so the whole
                      pipeline can run offline.

Usage:
    python -m ml.collect_data                 # simulated (default)
    python -m ml.collect_data --city London --days 730
    python -m ml.collect_data --live          # requires API key
"""

import argparse
import os
import time
import logging
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

from config import Config

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)


# --------------------------------------------------------------------
# Simulated data generator
# --------------------------------------------------------------------
CITY_PROFILES = {
    # name: (lat, lon, mean_temp, amplitude, rainfall_prob, humidity_base)
    "London":   (51.51, -0.13, 11.0, 7.0, 0.42, 78),
    "Paris":    (48.85,  2.35, 12.0, 8.0, 0.38, 74),
    "New York": (40.71, -74.01, 13.0, 11.0, 0.33, 68),
    "Tokyo":    (35.68, 139.69, 16.0, 9.0, 0.45, 70),
    "Sydney":   (-33.87, 151.21, 18.0, 6.0, 0.36, 66),
    "Mumbai":   (19.08, 72.88, 27.0, 4.0, 0.30, 72),
    "Cairo":    (30.04, 31.24, 23.0, 8.0, 0.08, 45),
    "Moscow":   (55.76, 37.62,  6.0, 12.0, 0.35, 76),
    "Berlin":   (52.52, 13.41, 10.0, 9.0, 0.40, 75),
    "Toronto":  (43.65, -79.38,  9.0, 13.0, 0.34, 70),
    "Singapore": (1.35, 103.82, 28.0, 1.5, 0.52, 84),
    "Dubai":    (25.20, 55.27, 28.0, 8.0, 0.05, 52),
}


def _synthetic_city(city: str, days: int, seed: int = 42) -> pd.DataFrame:
    """Generate a realistic daily weather series for one city."""
    rng = np.random.default_rng(seed + hash(city) % 10_000)
    lat, lon, mean_t, amp, rain_p, humid = CITY_PROFILES.get(
        city, (0.0, 0.0, 15.0, 8.0, 0.35, 70)
    )

    dates = pd.date_range(end=datetime.utcnow().date(), periods=days, freq="D")
    doy = dates.dayofyear.to_numpy()

    # Seasonal temperature wave (Northern/Southern hemisphere aware)
    phase = 0.0 if lat >= 0 else np.pi
    seasonal = mean_t + amp * np.sin(2 * np.pi * (doy - 105) / 365.25 + phase)

    # Multi-scale noise: slow drift + daily jitter
    drift = np.convolve(rng.normal(0, 0.6, len(dates)),
                        np.ones(7) / 7, mode="same")
    noise = rng.normal(0, 1.2, len(dates))
    temp_mean = seasonal + drift + noise
    temp_min = temp_mean - rng.uniform(3, 6, len(dates))
    temp_max = temp_mean + rng.uniform(3, 6, len(dates))

    # Rainfall: Markov-ish persistence + seasonal modulation
    wetness = 0.5 + 0.5 * np.sin(2 * np.pi * (doy - 60) / 365.25 + phase)
    p_rain = np.clip(rain_p * (0.5 + wetness), 0.02, 0.9)
    raining = rng.random(len(dates)) < p_rain
    rainfall = np.where(raining, np.round(rng.exponential(4.0, len(dates)), 1), 0.0)

    humidity = np.clip(humid + rng.normal(0, 8, len(dates)) + 0.8 * (rainfall > 0) * 15, 15, 100)
    wind = np.round(np.clip(rng.gamma(2.0, 4.0, len(dates)), 0, 60), 1)
    pressure = np.round(1013 + 6 * np.sin(2 * np.pi * (doy - 200) / 365.25)
                        + rng.normal(0, 4, len(dates)), 1)

    return pd.DataFrame({
        "date": dates.strftime("%Y-%m-%d"),
        "city": city,
        "temperature_min": np.round(temp_min, 1),
        "temperature_max": np.round(temp_max, 1),
        "temperature_mean": np.round(temp_mean, 1),
        "rainfall_mm": rainfall,
        "humidity_pct": np.round(humidity, 0).astype(int),
        "wind_kph": wind,
        "pressure_hpa": pressure,
        "latitude": lat,
        "longitude": lon,
    })


def collect_simulated(cities=None, days: int = 730) -> pd.DataFrame:
    """Collect synthetic data for all (or given) cities."""
    cities = cities or list(CITY_PROFILES.keys())
    frames = [_synthetic_city(c, days) for c in cities]
    df = pd.concat(frames, ignore_index=True)
    out = Config.RAW_DATA
    df.to_csv(out, index=False)
    log.info("Simulated %d rows for %d cities -> %s", len(df), len(cities), out)
    return df


# --------------------------------------------------------------------
# Live collection via OpenWeatherMap
# --------------------------------------------------------------------
def collect_live(city: str, days: int = 730) -> pd.DataFrame:
    """Download historical daily data via OpenWeatherMap One Call API."""
    import requests

    key = Config.WEATHER_API_KEY
    if not key:
        raise RuntimeError("WEATHER_API_KEY not set — cannot use --live mode")

    lat, lon = CITY_PROFILES.get(city, (51.51, -0.13))[:2]
    rows = []
    end = int(time.time())
    step = 365 * 24 * 3600  # API limit: one request per year block

    for _ in range((days // 365) + 1):
        url = f"{Config.WEATHER_API_BASE}/onecall/timemachine"
        params = {"lat": lat, "lon": lon, "dt": end, "appid": key, "units": "metric"}
        resp = requests.get(url, params=params, timeout=30)
        resp.raise_for_status()
        for day in resp.json().get("hourly", []):
            rows.append({
                "date": datetime.utcfromtimestamp(day["dt"]).strftime("%Y-%m-%d"),
                "city": city,
                "temperature_mean": day["temp"],
                "humidity_pct": day["humidity"],
                "wind_kph": round(day.get("wind_speed", 0) * 3.6, 1),
                "pressure_hpa": day["pressure"],
                "rainfall_mm": day.get("rain", {}).get("1h", 0.0) * 24,
            })
        end -= step

    df = pd.DataFrame(rows).groupby(["date", "city"], as_index=False).agg({
        "temperature_mean": "mean", "humidity_pct": "mean",
        "wind_kph": "mean", "pressure_hpa": "mean", "rainfall_mm": "sum",
    }).round(1)
    df["temperature_mean"] = df["temperature_mean"].round(1)
    df.to_csv(Config.RAW_DATA, index=False)
    log.info("Live-collected %d rows for %s -> %s", len(df), city, Config.RAW_DATA)
    return df


# --------------------------------------------------------------------
# CLI entry point
# --------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Collect weather data")
    parser.add_argument("--live", action="store_true", help="use live API")
    parser.add_argument("--city", default="London")
    parser.add_argument("--days", type=int, default=730)
    args = parser.parse_args()

    if args.live:
        collect_live(args.city, args.days)
    else:
        collect_simulated(days=args.days)


if __name__ == "__main__":
    main()
