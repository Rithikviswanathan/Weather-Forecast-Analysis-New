"""
train_model.py
==============
Trains two models on the processed dataset:
  1. temperature_model.pkl — RandomForestRegressor for temperature_mean
  2. rainfall_model.pkl    — RandomForestClassifier for rain (binary)

Also computes feature importances and persists them alongside the model.

Usage:
    python -m ml.train_model
"""

import json
import logging
from pathlib import Path

import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split

from config import Config
from ml.feature_engineering import build_features, FEATURE_COLUMNS

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)


def load_dataset():
    df = pd.read_csv(Config.PROCESSED_DATA, parse_dates=["date"])
    X, y_temp, y_rain, _ = build_features(df)
    return X, y_temp, y_rain


def train_temperature(X, y):
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=Config.TRAIN_TEST_SPLIT,
        random_state=Config.RANDOM_STATE, shuffle=False,
    )
    model = RandomForestRegressor(
        n_estimators=200, max_depth=16, min_samples_split=4,
        n_jobs=-1, random_state=Config.RANDOM_STATE,
    )
    model.fit(X_tr, y_tr)
    score = model.score(X_te, y_te)
    log.info("Temperature model R^2 on hold-out: %.3f", score)
    return model, score


def train_rainfall(X, y):
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=Config.TRAIN_TEST_SPLIT,
        random_state=Config.RANDOM_STATE, shuffle=False,
    )
    model = RandomForestClassifier(
        n_estimators=200, max_depth=14, min_samples_split=4,
        class_weight="balanced", n_jobs=-1, random_state=Config.RANDOM_STATE,
    )
    model.fit(X_tr, y_tr)
    score = model.score(X_te, y_te)
    log.info("Rainfall model accuracy on hold-out: %.3f", score)
    return model, score


def save_importances(model, filename):
    imp = pd.Series(model.feature_importances_, index=FEATURE_COLUMNS)
    imp = imp.sort_values(ascending=False)
    path = Config.MODEL_DIR / filename
    imp.to_json(path)
    log.info("Feature importances -> %s", path)


def train_all():
    Config.MODEL_DIR.mkdir(exist_ok=True)
    X, y_temp, y_rain = load_dataset()

    t_model, t_score = train_temperature(X, y_temp)
    joblib.dump(t_model, Config.TEMP_MODEL)
    save_importances(t_model, "temperature_importances.json")

    r_model, r_score = train_rainfall(X, y_rain)
    joblib.dump(r_model, Config.RAIN_MODEL)
    save_importances(r_model, "rainfall_importances.json")

    results = {
        "temperature_r2": round(t_score, 4),
        "rainfall_accuracy": round(r_score, 4),
        "n_samples": len(X),
        "n_features": X.shape[1],
        "trained_at": pd.Timestamp.utcnow().isoformat(),
    }
    log.info("Training complete: %s", results)
    return results


if __name__ == "__main__":
    train_all()
