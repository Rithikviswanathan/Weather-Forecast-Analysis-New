"""
preprocess.py
=============
Reads the raw CSV, cleans it (missing values, outliers, types, dedup),
and writes data/processed/cleaned_weather.csv.

Usage:
    python -m ml.preprocess
"""

import logging
import numpy as np
import pandas as pd

from config import Config

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)


def load_raw(path=None) -> pd.DataFrame:
    df = pd.read_csv(path or Config.RAW_DATA)
    log.info("Loaded raw data: %d rows x %d cols", *df.shape)
    return df


def parse_dates(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df = df.dropna(subset=["date"])
    return df


def handle_missing(df: pd.DataFrame) -> pd.DataFrame:
    """Forward/backward fill within each city, then global fallback."""
    df = df.sort_values(["city", "date"])
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    df[numeric_cols] = (
        df.groupby("city")[numeric_cols]
        .transform(lambda g: g.ffill().bfill())
    )
    df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].median())
    return df


def remove_outliers(df: pd.DataFrame) -> pd.DataFrame:
    """Clamp values to physically plausible ranges."""
    df = df.copy()
    df["temperature_min"] = df["temperature_min"].clip(-60, 55)
    df["temperature_max"] = df["temperature_max"].clip(-60, 60)
    # Ensure min <= max
    swap = df["temperature_min"] > df["temperature_max"]
    df.loc[swap, ["temperature_min", "temperature_max"]] = df.loc[
        swap, ["temperature_max", "temperature_min"]
    ].to_numpy()
    df["humidity_pct"] = df["humidity_pct"].clip(0, 100)
    df["rainfall_mm"] = df["rainfall_mm"].clip(lower=0)
    df["wind_kph"] = df["wind_kph"].clip(lower=0)
    df["pressure_hpa"] = df["pressure_hpa"].clip(870, 1080)
    return df


def deduplicate(df: pd.DataFrame) -> pd.DataFrame:
    before = len(df)
    df = df.drop_duplicates(subset=["city", "date"], keep="last")
    if before - len(df):
        log.info("Dropped %d duplicate rows", before - len(df))
    return df


def add_derived_columns(df: pd.DataFrame) -> pd.DataFrame:
    if "temperature_mean" not in df or df["temperature_mean"].isna().all():
        df["temperature_mean"] = (df["temperature_min"] + df["temperature_max"]) / 2
    df["rain"] = (df["rainfall_mm"] > 0.5).astype(int)  # binary target
    return df


def run_pipeline(input_path=None, output_path=None) -> pd.DataFrame:
    df = load_raw(input_path)
    df = parse_dates(df)
    df = deduplicate(df)
    df = handle_missing(df)
    df = remove_outliers(df)
    df = add_derived_columns(df)
    out = output_path or Config.PROCESSED_DATA
    df.to_csv(out, index=False)
    log.info("Saved cleaned data (%d rows) -> %s", len(df), out)
    return df


if __name__ == "__main__":
    run_pipeline()
