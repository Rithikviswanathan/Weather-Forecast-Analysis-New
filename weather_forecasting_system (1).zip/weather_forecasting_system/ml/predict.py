"""
predict.py
==========
Loads the trained models and generates weather predictions.

Used both by the web service layer and as a standalone script.

Usage:
    python -m ml.predict --city London --days 7
"""

import argparse
import logging

import joblib
import numpy as np
import pandas as pd

from config import Config
from ml.feature_engineering import FEATURE_COLUMNS, build_features

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)


def _load_models():
    temp = joblib.load(Config.TEMP_MODEL)
    rain = joblib.load(Config.RAIN_MODEL)
    return temp, rain


def forecast_next_days(city: str, days: int = 7) -> pd.DataFrame:
    """
    Recursive multi-day forecast: predict one day, append it to the
    history, then predict the next — for `days` iterations.
    """
    df = pd.read_csv(Config.PROCESSED_DATA, parse_dates=["date"])
    df = df[df["city"] == city].sort_values("date").copy()
    if df.empty:
        raise ValueError(f"No processed data for city '{city}'")

    temp_model, rain_model = _load_models()
    history = df.tail(30).copy()
    forecasts = []

    for i in range(days):
        # Build a candidate row for the next day
        last_date = history["date"].max()
        next_date = last_date + pd.Timedelta(days=1)
        last = history.iloc[-1]

        candidate = pd.DataFrame([{
            "date": next_date,
            "city": city,
            "temperature_min": last["temperature_min"],
            "temperature_max": last["temperature_max"],
            "temperature_mean": last["temperature_mean"],
            "rainfall_mm": last["rainfall_mm"],
            "humidity_pct": last["humidity_pct"],
            "wind_kph": last["wind_kph"],
            "pressure_hpa": last["pressure_hpa"],
            "latitude": last["latitude"],
            "longitude": last["longitude"],
            "rain": last.get("rain", 0),
        }])

        combined = pd.concat([history, candidate], ignore_index=True)
        X, _, _, full = build_features(combined)
        X_next = X.tail(1)[FEATURE_COLUMNS]

        pred_temp = float(temp_model.predict(X_next)[0])
        pred_rain = int(rain_model.predict(X_next)[0])
        rain_proba = float(rain_model.predict_proba(X_next)[0][1])

        record = {
            "date": next_date.strftime("%Y-%m-%d"),
            "city": city,
            "predicted_temperature": round(pred_temp, 1),
            "predicted_rain": pred_rain,
            "rain_probability": round(rain_proba, 3),
            "humidity_pct": int(last["humidity_pct"]),
            "wind_kph": round(float(last["wind_kph"]), 1),
        }
        forecasts.append(record)

        # Feed prediction back into history for the next iteration
        candidate.loc[0, "temperature_mean"] = pred_temp
        candidate.loc[0, "rainfall_mm"] = 4.0 if pred_rain else 0.0
        candidate.loc[0, "rain"] = pred_rain
        history = pd.concat([history, candidate], ignore_index=True)

    return pd.DataFrame(forecasts)


def predict_single(features: pd.DataFrame) -> dict:
    """One-shot prediction from a feature row (used by the API)."""
    temp_model, rain_model = _load_models()
    X = features[FEATURE_COLUMNS].tail(1)
    return {
        "temperature": round(float(temp_model.predict(X)[0]), 1),
        "rain": int(rain_model.predict(X)[0]),
        "rain_probability": round(float(rain_model.predict_proba(X)[0][1]), 3),
    }


def main():
    parser = argparse.ArgumentParser(description="Generate weather predictions")
    parser.add_argument("--city", default="London")
    parser.add_argument("--days", type=int, default=7)
    args = parser.parse_args()

    out = forecast_next_days(args.city, args.days)
    print(out.to_string(index=False))


if __name__ == "__main__":
    main()
