"""
feature_engineering.py
======================
Transforms cleaned daily weather data into model-ready features:
calendar features, lag features, rolling statistics, and interactions.

Usage:
    from ml.feature_engineering import build_features
    X, y_temp, y_rain = build_features(df)
"""

import numpy as np
import pandas as pd


LAG_DAYS = [1, 2, 3, 7]
ROLL_WINDOWS = [3, 7, 14]


def calendar_features(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["day_of_year"] = df["date"].dt.dayofyear
    df["month"] = df["date"].dt.month
    df["weekday"] = df["date"].dt.weekday
    df["is_weekend"] = (df["weekday"] >= 5).astype(int)
    # Cyclical encoding so Jan 31 and Feb 1 are "close"
    df["doy_sin"] = np.sin(2 * np.pi * df["day_of_year"] / 365.25)
    df["doy_cos"] = np.cos(2 * np.pi * df["day_of_year"] / 365.25)
    return df


def lag_features(df: pd.DataFrame, cols=("temperature_mean", "rainfall_mm",
                                         "humidity_pct", "pressure_hpa")) -> pd.DataFrame:
    df = df.sort_values(["city", "date"]).copy()
    for col in cols:
        for lag in LAG_DAYS:
            df[f"{col}_lag{lag}"] = df.groupby("city")[col].shift(lag)
    return df


def rolling_features(df: pd.DataFrame, cols=("temperature_mean", "rainfall_mm")) -> pd.DataFrame:
    for col in cols:
        for w in ROLL_WINDOWS:
            grp = df.groupby("city")[col]
            df[f"{col}_roll{w}_mean"] = grp.transform(lambda s: s.shift(1).rolling(w).mean())
            df[f"{col}_roll{w}_std"] = grp.transform(lambda s: s.shift(1).rolling(w).std())
    return df


def interaction_features(df: pd.DataFrame) -> pd.DataFrame:
    df["temp_humidity"] = df["temperature_mean"] * df["humidity_pct"] / 100
    df["temp_range"] = df["temperature_max"] - df["temperature_min"]
    return df


FEATURE_COLUMNS = [
    "latitude", "longitude",
    "day_of_year", "month", "weekday", "is_weekend", "doy_sin", "doy_cos",
    "humidity_pct", "wind_kph", "pressure_hpa", "temp_range",
    "temperature_mean_lag1", "temperature_mean_lag2", "temperature_mean_lag7",
    "rainfall_mm_lag1", "rainfall_mm_lag7",
    "humidity_pct_lag1", "pressure_hpa_lag1",
    "temperature_mean_roll3_mean", "temperature_mean_roll7_mean",
    "temperature_mean_roll7_std",
    "rainfall_mm_roll7_mean", "rainfall_mm_roll14_mean",
    "temp_humidity",
]

TARGET_TEMP = "temperature_mean"
TARGET_RAIN = "rain"


def build_features(df: pd.DataFrame):
    """
    Returns (X, y_temp, y_rain, feature_df) with NaN rows dropped.
    y_rain is None if the binary 'rain' column is absent.
    """
    df = calendar_features(df)
    df = lag_features(df)
    df = rolling_features(df)
    df = interaction_features(df)

    df = df.dropna(subset=FEATURE_COLUMNS + [TARGET_TEMP]).reset_index(drop=True)

    X = df[FEATURE_COLUMNS].copy()
    y_temp = df[TARGET_TEMP].copy()
    y_rain = df[TARGET_RAIN].copy() if TARGET_RAIN in df else None
    return X, y_temp, y_rain, df


if __name__ == "__main__":
    from ml.preprocess import run_pipeline
    from config import Config
    df = run_pipeline()
    X, y_temp, y_rain, _ = build_features(df)
    print(f"Features: {X.shape[1]} | rows: {len(X)}")
    print("Target temp range:", round(y_temp.min(), 1), "-", round(y_temp.max(), 1))
