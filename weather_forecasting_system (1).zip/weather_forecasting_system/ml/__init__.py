"""Machine learning pipeline for the weather forecasting system."""

__version__ = "1.0.0"
