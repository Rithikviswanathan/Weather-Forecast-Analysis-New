"""
evaluate_model.py
=================
Evaluates the trained models on a hold-out split and writes
models/model_metrics.json with regression and classification metrics.

Usage:
    python -m ml.evaluate_model
"""

import json
import logging

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix,
    f1_score, mean_absolute_error, mean_squared_error, r2_score, roc_auc_score,
)

from config import Config
from ml.feature_engineering import build_features

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)


def evaluate():
    df = pd.read_csv(Config.PROCESSED_DATA, parse_dates=["date"])
    X, y_temp, y_rain, _ = build_features(df)

    n_test = max(int(len(X) * Config.TRAIN_TEST_SPLIT), 1)
    X_test = X.iloc[-n_test:]
    y_temp_test = y_temp.iloc[-n_test:]
    y_rain_test = y_rain.iloc[-n_test:]

    metrics = {"evaluated_at": pd.Timestamp.utcnow().isoformat(), "n_test": n_test}

    # --- Temperature (regression) ---
    if Config.TEMP_MODEL.exists():
        t_model = joblib.load(Config.TEMP_MODEL)
        preds = t_model.predict(X_test)
        metrics["temperature"] = {
            "r2": round(r2_score(y_temp_test, preds), 4),
            "rmse": round(float(np.sqrt(mean_squared_error(y_temp_test, preds))), 3),
            "mae": round(float(mean_absolute_error(y_temp_test, preds)), 3),
        }
        # Save residuals for the performance page chart
        residuals = pd.DataFrame({
            "date": df["date"].iloc[-n_test:].dt.strftime("%Y-%m-%d"),
            "actual": y_temp_test.values, "predicted": preds,
        })
        residuals.to_csv(Config.MODEL_DIR / "temperature_residuals.csv", index=False)

    # --- Rainfall (classification) ---
    if Config.RAIN_MODEL.exists():
        r_model = joblib.load(Config.RAIN_MODEL)
        preds_r = r_model.predict(X_test)
        proba = r_model.predict_proba(X_test)[:, 1] if hasattr(r_model, "predict_proba") else None
        rain_metrics = {
            "accuracy": round(accuracy_score(y_rain_test, preds_r), 4),
            "f1": round(f1_score(y_rain_test, preds_r), 4),
            "confusion_matrix": confusion_matrix(y_rain_test, preds_r).tolist(),
        }
        if proba is not None and len(np.unique(y_rain_test)) > 1:
            rain_metrics["roc_auc"] = round(roc_auc_score(y_rain_test, proba), 4)
        rain_metrics["report"] = classification_report(
            y_rain_test, preds_r, output_dict=True, zero_division=0
        )
        metrics["rainfall"] = rain_metrics

    out = Config.MODEL_DIR / "model_metrics.json"
    with open(out, "w") as f:
        json.dump(metrics, f, indent=2)
    log.info("Metrics written to %s", out)
    return metrics


if __name__ == "__main__":
    print(json.dumps(evaluate(), indent=2))
