/**
 * charts.js — Chart.js helpers for dashboard, forecast & performance pages.
 * Assumes Chart.js 4.x is loaded globally.
 */

const ChartTheme = {
    color: "#94a3b8",
    grid: "rgba(148,163,184,.12)",
    temp: "#38bdf8",
    rain: "#818cf8",
    actual: "#34d399",
    predicted: "#f59e0b",
};

function baseOpts() {
    return {
        responsive: true,
        plugins: { legend: { labels: { color: ChartTheme.color } } },
        scales: {
            x: { ticks: { color: ChartTheme.color }, grid: { color: ChartTheme.grid } },
            y: { ticks: { color: ChartTheme.color }, grid: { color: ChartTheme.grid } },
        },
    };
}

/* ---------- Dashboard: 7-day temperature outlook ---------- */
const DashboardChart = {
    init(city) {
        const el = document.getElementById("dashboard-chart");
        if (!el) return;
        fetch(`/api/forecast?city=${encodeURIComponent(city)}&days=7`)
            .then((r) => r.json())
            .then((rows) => {
                new Chart(el, {
                    type: "line",
                    data: {
                        labels: rows.map((d) => d.date),
                        datasets: [{
                            label: "Predicted °C",
                            data: rows.map((d) => d.predicted_temperature),
                            borderColor: ChartTheme.temp,
                            backgroundColor: "rgba(56,189,248,.15)",
                            fill: true, tension: .35, pointRadius: 4,
                        }],
                    },
                    options: baseOpts(),
                });
            })
            .catch(() => { el.replaceWith(document.createTextNode("Chart unavailable")); });
    },
};

/* ---------- Forecast page: temp + rain probability ---------- */
const ForecastChart = {
    init(city, days) {
        const el = document.getElementById("forecast-chart");
        if (!el) return;
        fetch(`/api/forecast?city=${encodeURIComponent(city)}&days=${days}`)
            .then((r) => r.json())
            .then((rows) => {
                new Chart(el, {
                    data: {
                        labels: rows.map((d) => d.date),
                        datasets: [
                            {
                                type: "line", label: "Temperature °C",
                                data: rows.map((d) => d.predicted_temperature),
                                borderColor: ChartTheme.temp, yAxisID: "y",
                                tension: .35, pointRadius: 4,
                            },
                            {
                                type: "bar", label: "Rain probability %",
                                data: rows.map((d) => Math.round((d.rain_probability || 0) * 100)),
                                backgroundColor: "rgba(129,140,248,.55)",
                                borderColor: ChartTheme.rain, yAxisID: "y1",
                            },
                        ],
                    },
                    options: {
                        ...baseOpts(),
                        scales: {
                            ...baseOpts().scales,
                            y1: { position: "right", min: 0, max: 100,
                                  ticks: { color: ChartTheme.color },
                                  grid: { drawOnChartArea: false } },
                        },
                    },
                });
            })
            .catch(() => { el.replaceWith(document.createTextNode("Chart unavailable")); });
    },
};

/* ---------- Performance page ---------- */
const PerformanceCharts = {
    async init() {
        await Promise.all([this.residuals(), this.importances()]);
    },

    async residuals() {
        const el = document.getElementById("residuals-chart");
        if (!el) return;
        const resp = await fetch("/static/../../models/temperature_residuals.csv").catch(() => null);
        if (!resp || !resp.ok) return; // CSV isn't served by Flask — skip gracefully

        const text = await resp.text();
        const lines = text.trim().split("\n").slice(1);
        const labels = [], actual = [], predicted = [];
        for (const line of lines) {
            const [date, a, p] = line.split(",");
            labels.push(date); actual.push(parseFloat(a)); predicted.push(parseFloat(p));
        }
        new Chart(el, {
            type: "line",
            data: {
                labels,
                datasets: [
                    { label: "Actual", data: actual, borderColor: ChartTheme.actual, pointRadius: 0 },
                    { label: "Predicted", data: predicted, borderColor: ChartTheme.predicted, pointRadius: 0 },
                ],
            },
            options: baseOpts(),
        });
    },

    async importances() {
        const el = document.getElementById("importance-chart");
        if (!el) return;
        try {
            const resp = await fetch("/api/metrics");
            if (!resp.ok) return;
            // Feature importances are stored server-side; metrics endpoint
            // returns evaluation metrics. Importances are embedded at render
            // time if present — fallback: hide this chart.
            el.closest(".panel").style.display = "none";
        } catch { /* ignore */ }
    },
};
