/**
 * main.js — general frontend interactions for the weather dashboard.
 */

// Mobile nav toggle
(function () {
    const toggle = document.getElementById("nav-toggle");
    const links = document.getElementById("nav-links");
    if (toggle && links) {
        toggle.addEventListener("click", () => links.classList.toggle("open"));
    }
})();

/**
 * CityAutocomplete — fetches known cities and wires them to a datalist.
 */
const CityAutocomplete = (() => {
    function init(inputId, listId) {
        const input = document.getElementById(inputId);
        const list = document.getElementById(listId);
        if (!input || !list) return;

        fetch("/api/cities")
            .then((r) => r.json())
            .then((cities) => {
                list.innerHTML = cities
                    .map((c) => `<option value="${c}">`)
                    .join("");
            })
            .catch(() => { /* offline — skip autocomplete */ });

        // Enter key submits
        input.addEventListener("keydown", (e) => {
            if (e.key === "Enter" && input.form) input.form.submit();
        });
    }
    return { init };
})();
