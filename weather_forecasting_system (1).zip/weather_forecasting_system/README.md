# Weather Forecasting System

A full-stack machine-learning web application that forecasts daily
**temperature** and **rainfall** for cities around the world.

Built with Flask (backend), scikit-learn (ML), SQLite (persistence),
pandas (data pipeline), and Chart.js (interactive front end).

---

## Features

- **Interactive dashboard** — current conditions + 3-day quick outlook + 7-day chart
- **Detailed forecasts** — up to 14 days, temperature + rain probability
- **Historical explorer** — filterable table of past weather per city
- **Model performance page** — R², RMSE, MAE, accuracy, F1, ROC-AUC, confusion matrix
- **Offline-capable** — works without an API key using realistic simulated data
- **Live API support** — plug in a free [OpenWeatherMap](https://openweathermap.org/api) key for real data

## Architecture

```
app.py                 → Flask app, routes & API endpoints
config.py              → configuration (env-var overridable)
ml/                    → ML pipeline
  collect_data.py      → raw data collection (live or simulated)
  preprocess.py        → cleaning, outlier handling, dedup
  feature_engineering  → lags, rolling stats, calendar cycles
  train_model.py       → RandomForest training (temp + rain)
  evaluate_model.py    → metrics → models/model_metrics.json
  predict.py           → recursive multi-day forecasting
services/              → business logic (forecast caching, weather API)
database/              → SQLite schema + helpers
templates/, static/    → Jinja2 UI + CSS/JS/Chart.js
tests/                 → pytest suite (app, predict, preprocess)
notebooks/             → exploratory data analysis
```

## Quick start

```bash
# 1. Create a virtual environment and install dependencies
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scriptsctivate
pip install -r requirements.txt

# 2. Build data, train and evaluate models (offline mode by default)
python -m ml.collect_data
python -m ml.preprocess
python -m ml.train_model
python -m ml.evaluate_model

# 3. Run the web app
python app.py
```

Open **http://127.0.0.1:5000** in your browser.

### Optional: live weather data

```bash
# .env
WEATHER_API_KEY=your-openweathermap-key
```

```bash
python -m ml.collect_data --live --city London --days 730
```

### Optional: run tests

```bash
pytest -v
```

### Optional: retrain via Flask CLI

```bash
flask --app app retrain
```

## API endpoints

| Endpoint | Description |
|---|---|
| `GET /api/forecast?city=London&days=7` | Daily forecast JSON |
| `GET /api/current?city=Paris` | Current conditions JSON |
| `GET /api/history?city=Tokyo&start=2024-01-01` | Historical records JSON |
| `GET /api/metrics` | Model evaluation metrics JSON |
| `GET /api/cities` | List of known cities |

## Models

| Model | Task | Algorithm | Metrics |
|---|---|---|---|
| `temperature_model.pkl` | Regression | RandomForestRegressor (200 trees) | R², RMSE, MAE |
| `rainfall_model.pkl` | Classification | RandomForestClassifier (balanced) | Accuracy, F1, ROC-AUC |

Features include calendar cycles (sin/cos), 1/2/3/7-day lags,
rolling means/std (3/7/14 days), and humidity–temperature interactions.

## Project layout

See the repository tree — every folder is documented inline with
docstrings and comments.

## License

MIT (educational project)
