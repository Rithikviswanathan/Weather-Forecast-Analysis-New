"""
forecast_service.py
===================
Business logic for forecasts and historical queries.

Wraps ml/predict.py forecasts, records them in the database,
and serves historical data from the processed dataset.
"""

import logging
import sqlite3
from datetime import datetime

import pandas as pd

from config import Config
from database.db import get_db, record_forecast
from ml.predict import forecast_next_days

log = logging.getLogger(__name__)


class ForecastService:
    # ----------------------------------------------------------------
    def daily_forecast(self, city: str, days: int = 7) -> list:
        """Generate (or fetch cached) daily forecast for `days` days."""
        days = max(1, min(days, Config.MAX_FORECAST_DAYS))

        # Serve cached forecast for today if present
        cached = self._cached_forecast(city, days)
        if cached:
            return cached

        try:
            df = forecast_next_days(city, days)
            records = df.to_dict(orient="records")
        except (ValueError, FileNotFoundError) as exc:
            log.warning("Model forecast unavailable (%s); using climatology", exc)
            records = self._climatology_fallback(city, days)

        # Persist to database for auditability
        for rec in records:
            try:
                record_forecast(
                    city=rec["city"], forecast_date=rec["date"],
                    temperature=rec.get("predicted_temperature"),
                    rain_probability=rec.get("rain_probability"),
                )
            except Exception:
                pass  # non-fatal
        return records

    # ----------------------------------------------------------------
    def quick_forecast(self, city: str) -> dict:
        """Short 3-day summary used on the dashboard."""
        daily = self.daily_forecast(city, days=3)
        temps = [d["predicted_temperature"] for d in daily]
        return {
            "days": daily,
            "avg_temp": round(sum(temps) / len(temps), 1) if temps else None,
            "rain_expected": any(d.get("predicted_rain") for d in daily),
        }

    # ----------------------------------------------------------------
    def historical(self, city: str, start: str = "", end: str = "") -> list:
        """Query historical weather from the processed dataset."""
        df = pd.read_csv(Config.PROCESSED_DATA, parse_dates=["date"])
        df = df[df["city"] == city]
        if start:
            df = df[df["date"] >= pd.to_datetime(start)]
        if end:
            df = df[df["date"] <= pd.to_datetime(end)]
        df = df.sort_values("date", ascending=False).head(365)
        out = df.copy()
        out["date"] = out["date"].dt.strftime("%Y-%m-%d")
        return out.to_dict(orient="records")

    # ----------------------------------------------------------------
    def _cached_forecast(self, city: str, days: int) -> list | None:
        today = datetime.utcnow().strftime("%Y-%m-%d")
        try:
            conn = get_db()
            cur = conn.execute(
                """SELECT forecast_date, temperature, rain_probability
                   FROM forecasts
                   WHERE city = ? AND created_date = ?
                   ORDER BY forecast_date LIMIT ?""",
                (city, today, days),
            )
            rows = cur.fetchall()
            conn.close()
            if len(rows) >= days:
                return [
                    {"city": city, "date": r["forecast_date"],
                     "predicted_temperature": r["temperature"],
                     "rain_probability": r["rain_probability"]}
                    for r in rows
                ]
        except sqlite3.Error:
            pass
        return None

    # ----------------------------------------------------------------
    def _climatology_fallback(self, city: str, days: int) -> list:
        """Seasonal-average fallback when no model/data is available."""
        df = pd.read_csv(Config.PROCESSED_DATA, parse_dates=["date"])
        df["month"] = df["date"].dt.month
        clim = df[df["city"] == city].groupby("month")["temperature_mean"].mean()
        base = clim.mean() if clim.empty else clim.mean()

        records, today = [], datetime.utcnow()
        for i in range(days):
            d = today + pd.Timedelta(days=i + 1)
            month_avg = float(clim.get(d.month, base))
            records.append({
                "date": d.strftime("%Y-%m-%d"),
                "city": city,
                "predicted_temperature": round(month_avg, 1),
                "predicted_rain": 0,
                "rain_probability": 0.3,
            })
        return records
