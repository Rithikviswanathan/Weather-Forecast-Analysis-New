"""
weather_service.py
==================
Fetches current weather conditions.

If WEATHER_API_KEY is set, calls OpenWeatherMap live. Otherwise it
returns realistic simulated conditions derived from the local
processed dataset, so the app always works offline.
"""

import logging
from datetime import datetime

import numpy as np
import pandas as pd

from config import Config

log = logging.getLogger(__name__)


class WeatherService:
    def __init__(self):
        self._cache = {}

    # ----------------------------------------------------------------
    def get_current(self, city: str) -> dict:
        key = Config.WEATHER_API_KEY
        if key:
            try:
                return self._fetch_live(city)
            except Exception as exc:  # fall back gracefully
                log.warning("Live fetch failed (%s); using simulated data", exc)
        return self._simulate(city)

    # ----------------------------------------------------------------
    def _fetch_live(self, city: str) -> dict:
        import requests
        url = f"{Config.WEATHER_API_BASE}/weather"
        params = {"q": city, "appid": Config.WEATHER_API_KEY, "units": "metric"}
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        return {
            "city": city,
            "temperature": data["main"]["temp"],
            "feels_like": data["main"]["feels_like"],
            "humidity": data["main"]["humidity"],
            "pressure": data["main"]["pressure"],
            "wind_kph": round(data.get("wind", {}).get("speed", 0) * 3.6, 1),
            "description": data["weather"][0]["description"].title(),
            "icon": data["weather"][0]["icon"],
            "source": "live",
            "fetched_at": datetime.utcnow().isoformat(),
        }

    # ----------------------------------------------------------------
    def _simulate(self, city: str) -> dict:
        """Derive 'current' conditions from recent historical rows."""
        try:
            df = pd.read_csv(Config.PROCESSED_DATA, parse_dates=["date"])
            rows = df[df["city"] == city].sort_values("date").tail(7)
        except FileNotFoundError:
            rows = pd.DataFrame()

        if rows.empty:
            rng = np.random.default_rng(abs(hash(city)) % 10_000)
            t_mean, rain_p, humid = 15.0, 0.3, 65
        else:
            t_mean = float(rows["temperature_mean"].mean())
            rain_p = float((rows["rainfall_mm"] > 0.5).mean())
            humid = int(rows["humidity_pct"].mean())

        rng = np.random.default_rng(int(datetime.utcnow().timestamp()) // 300)
        temperature = round(t_mean + rng.normal(0, 1.0), 1)
        raining = rng.random() < rain_p
        description = "Light rain" if raining else "Partly cloudy"
        if temperature > 25 and not raining:
            description = "Sunny"
        elif temperature < 2:
            description = "Cold and clear"

        return {
            "city": city,
            "temperature": temperature,
            "feels_like": round(temperature - 2 if description == "Cold and clear"
                                else temperature + 1, 1),
            "humidity": humid,
            "pressure": 1013,
            "wind_kph": round(float(rng.gamma(2, 4)), 1),
            "description": description,
            "icon": "10d" if raining else "02d",
            "source": "simulated",
            "fetched_at": datetime.utcnow().isoformat(),
        }
