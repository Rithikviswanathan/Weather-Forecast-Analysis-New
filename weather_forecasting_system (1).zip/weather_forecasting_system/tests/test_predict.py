"""Tests for ml/predict.py."""

import numpy as np
import pandas as pd
import pytest
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
import joblib

from config import Config


@pytest.fixture(scope="module")
def trained_models(tmp_path_factory):
    """Train tiny models on synthetic data so tests are fast and offline."""
    rng = np.random.default_rng(0)
    n = 200
    X = pd.DataFrame({
        "latitude": 51.5, "longitude": -0.1,
        "day_of_year": np.tile(np.arange(1, 101), 2),
        "month": np.tile(np.arange(1, 101), 2) % 12 + 1,
        "weekday": np.arange(n) % 7, "is_weekend": np.arange(n) % 7 >= 5,
        "doy_sin": np.sin(np.arange(n)), "doy_cos": np.cos(np.arange(n)),
        "humidity_pct": rng.uniform(40, 90, n),
        "wind_kph": rng.uniform(0, 40, n),
        "pressure_hpa": rng.uniform(990, 1030, n),
        "temp_range": rng.uniform(3, 10, n),
        "temperature_mean_lag1": rng.normal(12, 5, n),
        "temperature_mean_lag2": rng.normal(12, 5, n),
        "temperature_mean_lag7": rng.normal(12, 5, n),
        "rainfall_mm_lag1": rng.exponential(2, n),
        "rainfall_mm_lag7": rng.exponential(2, n),
        "humidity_pct_lag1": rng.uniform(40, 90, n),
        "pressure_hpa_lag1": rng.uniform(990, 1030, n),
        "temperature_mean_roll3_mean": rng.normal(12, 5, n),
        "temperature_mean_roll7_mean": rng.normal(12, 5, n),
        "temperature_mean_roll7_std": rng.uniform(0.5, 3, n),
        "rainfall_mm_roll7_mean": rng.exponential(2, n),
        "rainfall_mm_roll14_mean": rng.exponential(2, n),
        "temp_humidity": rng.uniform(5, 25, n),
    })
    y_temp = rng.normal(12, 5, n)
    y_rain = (rng.random(n) > 0.6).astype(int)

    t = RandomForestRegressor(n_estimators=5, random_state=0).fit(X, y_temp)
    r = RandomForestClassifier(n_estimators=5, random_state=0).fit(X, y_rain)

    tmp = tmp_path_factory.mktemp("models")
    t_path, r_path = tmp / "t.pkl", tmp / "r.pkl"
    joblib.dump(t, t_path)
    joblib.dump(r, r_path)

    return str(t_path), str(r_path)


def test_models_predict_proba(trained_models):
    from ml.feature_engineering import FEATURE_COLUMNS
    t_path, r_path = trained_models
    t = joblib.load(t_path)
    r = joblib.load(r_path)
    rng = np.random.default_rng(1)
    row = pd.DataFrame({c: rng.normal(size=1) for c in FEATURE_COLUMNS})
    pred_t = t.predict(row[FEATURE_COLUMNS])
    pred_r = r.predict(row[FEATURE_COLUMNS])
    proba = r.predict_proba(row[FEATURE_COLUMNS])[0]
    assert len(pred_t) == 1
    assert pred_r[0] in (0, 1)
    assert np.isclose(proba.sum(), 1.0)


def test_forecast_output_shape(monkeypatch, tmp_path, trained_models):
    from ml import predict as predict_mod

    t_path, r_path = trained_models
    monkeypatch.setattr(Config, "TEMP_MODEL", __import__("pathlib").Path(t_path))
    monkeypatch.setattr(Config, "RAIN_MODEL", __import__("pathlib").Path(r_path))
    monkeypatch.setattr(Config, "PROCESSED_DATA",
                        tmp_path / "cleaned_weather.csv")

    # Build a minimal processed dataset with enough history
    dates = pd.date_range("2024-01-01", periods=60, freq="D")
    pd.DataFrame({
        "date": dates,
        "city": ["TestCity"] * 60,
        "temperature_min": np.linspace(0, 10, 60),
        "temperature_max": np.linspace(6, 16, 60),
        "temperature_mean": np.linspace(3, 13, 60),
        "rainfall_mm": (np.arange(60) % 5 == 0).astype(float) * 2,
        "humidity_pct": [70] * 60, "wind_kph": [10.0] * 60,
        "pressure_hpa": [1013.0] * 60,
        "latitude": 51.5, "longitude": -0.1, "rain": [0, 1] * 30,
    }).to_csv(tmp_path / "cleaned_weather.csv", index=False)

    out = predict_mod.forecast_next_days("TestCity", days=5)
    assert len(out) == 5
    assert list(out.columns) == [
        "date", "city", "predicted_temperature",
        "predicted_rain", "rain_probability",
        "humidity_pct", "wind_kph",
    ]
    assert (out["predicted_rain"].isin([0, 1])).all()
    assert ((out["rain_probability"] >= 0) & (out["rain_probability"] <= 1)).all()
