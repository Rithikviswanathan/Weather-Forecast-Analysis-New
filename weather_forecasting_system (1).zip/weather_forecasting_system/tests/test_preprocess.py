"""Tests for ml/preprocess.py."""

import numpy as np
import pandas as pd
import pytest

from ml.preprocess import (
    parse_dates, deduplicate, handle_missing,
    remove_outliers, add_derived_columns, run_pipeline,
)


@pytest.fixture
def dirty_df():
    return pd.DataFrame({
        "date": ["2024-01-01", "2024-01-01", "2024-01-02", "2024-01-03", "bad-date"],
        "city": ["London", "London", "London", "London", "London"],
        "temperature_min": [5.0, 5.0, 100.0, np.nan, 10.0],
        "temperature_max": [12.0, 12.0, -5.0, 14.0, 20.0],
        "rainfall_mm": [0.0, 0.0, -3.0, np.nan, 0.0],
        "humidity_pct": [80, 80, 150, 60, 50],
        "wind_kph": [10, 10, 5, 8, 6],
        "pressure_hpa": [1013, 1013, 1010, 1005, 1015],
    })


def test_parse_dates_drops_invalid(dirty_df):
    df = parse_dates(dirty_df)
    assert df["date"].notna().all()
    assert str(df["date"].dtype).startswith("datetime64")


def test_deduplicate(dirty_df):
    df = parse_dates(dirty_df)
    df = deduplicate(df)
    assert not df.duplicated(subset=["city", "date"]).any()


def test_missing_values_filled(dirty_df):
    df = parse_dates(dirty_df)
    df = handle_missing(df)
    numeric = df.select_dtypes(include=[np.number])
    assert numeric.notna().all().all()


def test_outliers_clamped(dirty_df):
    df = parse_dates(dirty_df)
    df = handle_missing(df)
    df = remove_outliers(df)
    assert df["temperature_min"].max() <= 55
    assert df["temperature_max"].min() >= -60
    assert df["temperature_min"].le(df["temperature_max"]).all()
    assert (df["humidity_pct"] <= 100).all()
    assert (df["rainfall_mm"] >= 0).all()


def test_rain_column_added(dirty_df):
    df = parse_dates(dirty_df)
    df = handle_missing(df)
    df = remove_outliers(df)
    df = add_derived_columns(df)
    assert "rain" in df.columns
    assert set(df["rain"].unique()) <= {0, 1}


def test_full_pipeline(tmp_path):
    raw = tmp_path / "raw.csv"
    pd.DataFrame({
        "date": ["2024-01-01", "2024-01-02", "2024-01-03"],
        "city": ["London"] * 3,
        "temperature_min": [1, 2, 3],
        "temperature_max": [8, 9, 10],
        "rainfall_mm": [0, 1, 0],
        "humidity_pct": [70, 75, 80],
        "wind_kph": [10, 12, 11],
        "pressure_hpa": [1010, 1012, 1011],
    }).to_csv(raw, index=False)

    out = tmp_path / "clean.csv"
    df = run_pipeline(input_path=raw, output_path=out)
    assert out.exists()
    assert len(df) == 3
    assert df["temperature_mean"].notna().all()
