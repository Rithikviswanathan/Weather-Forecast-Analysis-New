"""Tests for the Flask application."""

import json
import os
import sys

import pytest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import create_app


@pytest.fixture(scope="module")
def client():
    os.environ["FLASK_DEBUG"] = "False"
    app = create_app()
    app.config["TESTING"] = True
    with app.test_client() as c:
        yield c


def test_index_page(client):
    resp = client.get("/")
    assert resp.status_code == 200
    assert b"Weather" in resp.data or b"weather" in resp.data


def test_about_page(client):
    resp = client.get("/about")
    assert resp.status_code == 200


def test_forecast_api(client):
    resp = client.get("/api/forecast?city=London&days=3")
    assert resp.status_code == 200
    data = resp.get_json()
    assert isinstance(data, list)
    assert len(data) == 3
    assert {"date", "city", "predicted_temperature"} <= set(data[0].keys())


def test_forecast_api_days_validation(client):
    resp = client.get("/api/forecast?days=99")
    assert resp.status_code == 400


def test_current_api(client):
    resp = client.get("/api/current?city=Paris")
    assert resp.status_code == 200
    data = resp.get_json()
    assert data["city"] == "Paris"
    assert "temperature" in data


def test_history_api(client):
    resp = client.get("/api/history?city=London")
    assert resp.status_code == 200
    assert isinstance(resp.get_json(), list)


def test_metrics_api(client):
    resp = client.get("/api/metrics")
    # 200 if metrics were generated, 404 otherwise — both acceptable
    assert resp.status_code in (200, 404)


def test_cities_api(client):
    resp = client.get("/api/cities")
    assert resp.status_code == 200
    assert "London" in resp.get_json()


def test_404(client):
    resp = client.get("/no-such-page")
    assert resp.status_code == 404
