"""
Weather Forecasting System — Main Flask Application
====================================================
Serves the web dashboard, historical data pages, forecast endpoints,
and model performance views.

Run with:
    python app.py
Then open http://127.0.0.1:5000 in your browser.
"""

import os
import json
import logging
from datetime import datetime

from flask import Flask, render_template, jsonify, request, abort

from config import Config
from services.forecast_service import ForecastService
from services.weather_service import WeatherService
from database.db import get_db, init_db

# --------------------------------------------------------------------
# Application factory
# --------------------------------------------------------------------
def create_app(config_class=Config):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Configure logging
    logging.basicConfig(
        level=getattr(logging, app.config.get("LOG_LEVEL", "INFO")),
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )

    # Initialise database tables if they don't exist
    with app.app_context():
        init_db()

    # ----------------------------------------------------------------
    # Blueprint-like route registration (kept inline for clarity)
    # ----------------------------------------------------------------
    forecast_service = ForecastService()
    weather_service = WeatherService()

    # ---------------------------------------------------------- views
    @app.route("/")
    def index():
        """Main dashboard: current conditions + quick forecast."""
        city = request.args.get("city", app.config["DEFAULT_CITY"])
        current = weather_service.get_current(city)
        quick = forecast_service.quick_forecast(city)
        return render_template(
            "index.html",
            city=city,
            current=current,
            quick=quick,
            year=datetime.utcnow().year,
        )

    @app.route("/forecast")
    def forecast():
        """Detailed 7-day forecast page for a given city."""
        city = request.args.get("city", app.config["DEFAULT_CITY"])
        days = int(request.args.get("days", 7))
        daily = forecast_service.daily_forecast(city, days=days)
        return render_template(
            "forecast.html",
            city=city,
            daily=daily,
            days=days,
            year=datetime.utcnow().year,
        )

    @app.route("/historical")
    def historical():
        """Historical weather explorer."""
        city = request.args.get("city", app.config["DEFAULT_CITY"])
        start = request.args.get("start", "")
        end = request.args.get("end", "")
        rows = forecast_service.historical(city, start=start, end=end)
        return render_template(
            "historical.html",
            city=city,
            rows=rows,
            start=start,
            end=end,
            year=datetime.utcnow().year,
        )

    @app.route("/performance")
    def performance():
        """Model evaluation metrics and charts."""
        metrics_path = os.path.join(app.config["MODEL_DIR"], "model_metrics.json")
        metrics = {}
        if os.path.exists(metrics_path):
            with open(metrics_path) as f:
                metrics = json.load(f)
        return render_template(
            "performance.html",
            metrics=metrics,
            year=datetime.utcnow().year,
        )

    @app.route("/about")
    def about():
        """Project information page."""
        return render_template("about.html", year=datetime.utcnow().year)

    # ---------------------------------------------------------- APIs
    @app.route("/api/forecast")
    def api_forecast():
        """JSON API: daily forecast for a city."""
        city = request.args.get("city", app.config["DEFAULT_CITY"])
        days = int(request.args.get("days", 7))
        if days < 1 or days > 14:
            abort(400, description="days must be between 1 and 14")
        return jsonify(forecast_service.daily_forecast(city, days=days))

    @app.route("/api/current")
    def api_current():
        """JSON API: current conditions (live or simulated)."""
        city = request.args.get("city", app.config["DEFAULT_CITY"])
        return jsonify(weather_service.get_current(city))

    @app.route("/api/history")
    def api_history():
        """JSON API: historical records from the database."""
        city = request.args.get("city", app.config["DEFAULT_CITY"])
        start = request.args.get("start", "")
        end = request.args.get("end", "")
        rows = forecast_service.historical(city, start=start, end=end)
        return jsonify(rows)

    @app.route("/api/metrics")
    def api_metrics():
        """JSON API: latest model evaluation metrics."""
        metrics_path = os.path.join(app.config["MODEL_DIR"], "model_metrics.json")
        if not os.path.exists(metrics_path):
            abort(404, description="metrics not found — run ml/evaluate_model.py")
        with open(metrics_path) as f:
            return jsonify(json.load(f))

    @app.route("/api/cities")
    def api_cities():
        """JSON API: list of known cities."""
        return jsonify(app.config["KNOWN_CITIES"])

    # ---------------------------------------------------------- misc
    @app.errorhandler(404)
    def not_found(e):
        return render_template(
            "base.html",
            content="<h1>404 — Page not found</h1>",
            year=datetime.utcnow().year,
        ), 404

    @app.cli.command("retrain")
    def retrain_command():
        """Flask CLI: retrain models from the processed dataset."""
        from ml.train_model import train_all
        results = train_all()
        print("Retrained models:", json.dumps(results, indent=2))

    return app


if __name__ == "__main__":
    app = create_app()
    app.run(
        host=app.config["HOST"],
        port=app.config["PORT"],
        debug=app.config["DEBUG"],
    )
